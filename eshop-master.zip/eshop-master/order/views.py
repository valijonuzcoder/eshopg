import json

from django.http import JsonResponse
from django.shortcuts import render, redirect

# Create your views here.
from .models import Order, OrderDetail, OrderAdd
from product.models import Product
from account.models import Customer
from utils.utils import get_order_count


def add_cart(request):
    if request.method == 'POST':
        data: dict = json.loads(request.body)
        product = Product.objects.get(id=data['product_id'])
        user_orders = request.user.orders.all().order_by('-id')
        if user_orders:
            order = user_orders.first()
        else:
            order = Order.objects.create(
                customer=request.user
            )
        order_detail = OrderDetail.objects.filter(
            order=order,
            product=product
        ).first()
        if order_detail:
            order_detail.delete()
        else:
            order_detail = OrderDetail.objects.create(
                order=order,
                product=product
            )


    return JsonResponse({'items_count': order.item_count()})

def orders_cart(request):
    if not request.user.is_authenticated:
        return redirect('login')
    else:
        order = request.user.orders.last()
        return render(
            request=request,
            template_name='orders/orders_cart.html',
            context={
                'order': order,
                'badge_count': get_order_count(request)
            }
        )

def change_quantity(request):
    item = None
    if request.method == 'POST':
        data:dict = json.loads(request.body)
        item_id = data.get('item',None)
        action = data.get('action',None)
        if item_id and action:
            item = OrderDetail.objects.get(id=item_id)
            item.change_quantity(action)
    response = {
        'error':False,
        'item_quantity': item.quantity,
        'item': item_id,
        'total_price': item.total_price(),
        'total':item.order.total_price()
    } if item else {
        'error': True
    }
    return JsonResponse(response)

def item_remove(request,id):
    try:
        item = OrderDetail.objects.get(id=id)
        order = item.order
        item.delete()
        success = True
    except:
        success = False
        order = None
    return JsonResponse({
        'success': success,
        'total':order.total_price() if order else 0,
        'id': id,
        'items_count':order.details.count()
    })

def to_order(request):

    orderto = request.user.orders.all()
    ordering = request.user()
    if request.method == 'POST':
        print(orderto)
        regions = request.POST.values()
        city = request.POST.get('city')
        orderget = OrderAdd.objects.create(
            orderadd = ordering,
            regions=regions,
            orderaddress=city
        )
        orderget.save()
        print(city,regions)
    order = request.user.orders.last()
    return render(
        request=request,
        template_name='orders/place-order.html',
        context = {
            'order': order,
            'badge_count': get_order_count(request)
        }
    )